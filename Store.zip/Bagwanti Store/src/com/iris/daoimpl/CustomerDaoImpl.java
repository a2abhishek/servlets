package com.iris.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.iris.daos.CustomerDao;
import com.iris.models.Customer;
import com.iris.utility.ConnectionProvider;

public class CustomerDaoImpl implements CustomerDao {
	Connection conn = ConnectionProvider.getConn();
	@Override
	public boolean registerCustomer(Customer cust) throws Exception {
	
			PreparedStatement ps=conn.prepareStatement("insert into customer values(id.nextval,?,?,?,?,?,'customer')");
			ps.setString(1,cust.getCustomerName());
			ps.setString(2,cust.getGender());
			ps.setString(3,cust.getEmailAddress());
			ps.setString(4,cust.getPassword());
			ps.setString(5,cust.getCity());
			int i=ps.executeUpdate();
			if(i!=0){
				return true;
			}
			
			return false;
		}
	
	@Override
	public Customer validateCustomer(String name, String password) throws Exception {
		PreparedStatement ps=conn.prepareStatement("select * from customer where name=? and password=?");
		ps.setString(1,name);
		ps.setString(2,password);
		
		ResultSet rs=ps.executeQuery();
		
		if(rs.next()){
			Customer c= new Customer();
			c.setCustomerId(rs.getInt(1));
			c.setCustomerName(rs.getString(2));
			c.setGender(rs.getString(3));
			c.setEmailAddress(rs.getString(4));
			c.setPassword(rs.getString(5));
			c.setCity(rs.getString(6));
			c.setRole(rs.getString(7));
			
			return c ;
		}
		return null;
	}

	@Override
	public List<Customer> viewAllCustomers() throws Exception {
		List<Customer> custList=new ArrayList<>();
		
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery("select * from customer where role='customer'");
		while(rs.next()){
			int id=rs.getInt(1);
			String name=rs.getString(2);
			String gen=rs.getString(3);
			String email=rs.getString(4);
			String pass=rs.getString(5);
			String city=rs.getString(6);
			String role=rs.getString(7);
			Customer cust=new Customer();
			cust.setCustomerId(id);
			cust.setCustomerName(name);
			cust.setGender(gen);
			cust.setEmailAddress(email);
			cust.setPassword(pass);
			cust.setCity(city);
			cust.setRole(role);
			
			custList.add(cust);			
		}
		return custList;
	}

	@Override
	public boolean deleteCustomer(int id) throws Exception {
		PreparedStatement ps=conn.prepareStatement("delete from customer where id=?");
		ps.setInt(1,id);
		int i=ps.executeUpdate();
		if(i!=0){
			return true;
		}
	
		return false;
	}

	@Override
	public Customer updateCustomer(int id) throws Exception {
		PreparedStatement ps=conn.prepareStatement("select * from customer where id=?");
		ps.setInt(1,id);

		
		ResultSet rs=ps.executeQuery();
		
		if(rs.next()){
			Customer c= new Customer();
			c.setCustomerId(rs.getInt(1));
			c.setCustomerName(rs.getString(2));
			c.setGender(rs.getString(3));
			c.setEmailAddress(rs.getString(4));
			c.setPassword(rs.getString(5));
			c.setCity(rs.getString(6));
			c.setRole(rs.getString(7));
			
			return c ;
		}
		return null;
	}

	@Override
	public boolean registerUpdatedCustomer(Customer cust) throws Exception {
		PreparedStatement ps=conn.prepareStatement("update customer set name=?, gender=?, email=?, password=?, city=? where id=?");
		ps.setString(1,cust.getCustomerName());
		ps.setString(2,cust.getGender());
		ps.setString(3,cust.getEmailAddress());
		ps.setString(4,cust.getPassword());
		ps.setString(5,cust.getCity());
		ps.setInt(6, cust.getCustomerId());
		int i=ps.executeUpdate();
		if(i!=0){
			return true;
		}
		
		return false;
	}
}
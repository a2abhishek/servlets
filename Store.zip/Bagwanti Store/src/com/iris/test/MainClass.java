package com.iris.test;

import java.util.Scanner;

import com.iris.daoimpl.CustomerDaoImpl;
import com.iris.daos.CustomerDao;
import com.iris.models.Customer;

public class MainClass {
	static Scanner sc=new Scanner(System.in);	
	static CustomerDao daoObj=new CustomerDaoImpl();
	
	public static void main(String[] args) {

		try {
			insert();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static void insert() throws Exception {
		System.out.println("Enter employee details");
		System.out.println("Enter Id");
		int id=sc.nextInt();
		System.out.println("Enter Name");
		String name=sc.next();
		System.out.println("Enter Gender");
		String gender=sc.next();
		System.out.println("Enter Email");
		String email=sc.next();
		System.out.println("Enter Password");
		String pass=sc.next();
		System.out.println("Enter City");
		String city=sc.next();
		
		Customer custom=new Customer();
		custom.setCustomerId(id);
		custom.setCustomerName(name);
		custom.setGender(gender);
		custom.setEmailAddress(email);
		custom.setPassword(pass);
		custom.setCity(city);
		
		boolean r=daoObj.registerCustomer(custom);
		if(r==true){
			System.out.println("Customer Registered");
		}
		else {
			System.out.println("Problem in Adding Customer");
		}
	}
}
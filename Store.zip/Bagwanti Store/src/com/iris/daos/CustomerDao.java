package com.iris.daos;

import java.util.List;

import com.iris.models.Customer;

public interface CustomerDao {
	public boolean registerCustomer(Customer cust) throws Exception;

	public Customer validateCustomer(String name, String password) throws Exception;
	public List<Customer> viewAllCustomers() throws Exception;
	public boolean deleteCustomer(int id) throws Exception;
	public Customer updateCustomer(int id) throws Exception;
	public boolean registerUpdatedCustomer(Customer cust) throws Exception;
}

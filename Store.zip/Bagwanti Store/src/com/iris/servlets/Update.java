package com.iris.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.daoimpl.CustomerDaoImpl;
import com.iris.daos.CustomerDao;
import com.iris.models.Customer;


@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		CustomerDao daoObj=new CustomerDaoImpl();
	
		String s1=request.getParameter("uid");		
		int id=Integer.parseInt(s1);
		Customer r =null ;
		try {
			r = daoObj.updateCustomer(id);
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(r!=null) {
			out.println("<style>");
			out.println("th {padding: 5px 10px;}");
			out.println("td {padding: 5px 10px;}");
			out.println("h2 {text-align: center;}");
			out.println("</style>");
			
			out.println("<form action='Updated' method='post'>");
			out.println("<table border=1px style='text-align=center'>");
			out.println("<tr><td>Id :<td>");
			out.println("<td><input type='text' name='id' value='"+r.getCustomerId()+"'readonly><td>");
			out.println("</tr>");
			out.println("<tr><td>Name :<td>");
			out.println("<td><input type='text' name='name' value='"+r.getCustomerName()+"'><td>");
			out.println("</tr>");
			out.println("<tr><td>Gender :<td>");
			out.println("<td><input type='text' name='gender' value='"+r.getGender()+"'><td>");
			out.println("</tr>");
			out.println("<tr><td>Email Address :<td>");
			out.println("<td><input type='text' name='email' value='"+r.getEmailAddress()+"'><td>");
			out.println("</tr>");
			out.println("<tr><td>Password :<td>");
			out.println("<td><input type='text' name='password' value='"+r.getPassword()+"'><td>");
			out.println("</tr>");
			out.println("<tr><td>City :<td>");
			out.println("<td><input type='text' name='city' value='"+r.getCity()+"'><td>");
			out.println("</tr>");
			out.println("<tr><td colspan='2'><input type='submit' value='Submit'><td>");
			out.println("</tr>");
			
			out.println("</table>");
			out.println("</form>");		
		}
	}
}

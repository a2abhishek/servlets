package com.iris.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.daoimpl.CustomerDaoImpl;
import com.iris.daos.CustomerDao;
import com.iris.models.Customer;


@WebServlet("/ViewAll")
public class ViewAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewAll() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//HttpSession session = request.getSession();
		//Customer obj=(Customer)session.getAttribute("CustObj");
		CustomerDao daoObj=new CustomerDaoImpl();
		List<Customer> a1 = new ArrayList<>();
		try {
			a1 = daoObj.viewAllCustomers();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		out.println("<style>");
		out.println("th {padding: 5px 10px;}");
		out.println("td {padding: 5px 10px;}");
		out.println("h2 {text-align: center;}");
		out.println("</style>");
		out.println("<h2>Customers List</h2>");
		out.println("<table style='border:1px solid black'>");
		out.println("<tr>");
		out.println("<th>Id</th>");
		out.println("<th>Name</th>");
		out.println("<th>Email</th>");
		out.println("<th>Gender</th>");
		out.println("<th>City</th>");
		out.println("<th>Password</th>");
		out.println("<th colspan='2'>Edit</th>");
		out.println("<br>");
		out.println("</tr>");
		for (Customer c : a1) {
			out.println("<tr>");
			out.println("<td>"+c.getCustomerId()+" </td>");
			out.println("<td>"+c.getCustomerName()+" </td>");
			out.println("<td>"+c.getEmailAddress()+" </td>");
			out.println("<td>"+c.getGender()+" </td>");
			out.println("<td>"+c.getCity()+" </td>");
			out.println("<td>"+c.getPassword()+" </td>");
			out.println("<td><a href='Update?uid="+c.getCustomerId()+"'>Update</a></td>");
			out.println("<td><a href='Delete?myid="+c.getCustomerId()+"'>Delete</a></td><br>");
			out.println("</tr>");
		}
		out.println("</table>");
		out.println("<form action='Logout' method='post'>");
		out.println("<input type='submit' value='Logout'>");
		out.println("</form>");
		
	}
		
}



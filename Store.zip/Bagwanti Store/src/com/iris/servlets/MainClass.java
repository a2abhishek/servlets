package com.iris.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.daoimpl.CustomerDaoImpl;
import com.iris.daos.CustomerDao;
import com.iris.models.Customer;

/**
 * Servlet implementation class MainClass
 */
@WebServlet("/MainClass")
public class MainClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		CustomerDao daoObj=new CustomerDaoImpl();
		
	
		String s2=request.getParameter("custName").toLowerCase();
		String s3=request.getParameter("gender");
		String s4=request.getParameter("email");
		String s5=request.getParameter("password");
		String s6=request.getParameter("city");
		

		Customer custom=new Customer();
		
		custom.setCustomerName(s2);
		custom.setGender(s3);
		custom.setEmailAddress(s4);
		custom.setPassword(s5);
		custom.setCity(s6);

		boolean r = false;
		try {
			r = daoObj.registerCustomer(custom);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(r==true){
			System.out.println("Customer Registered");
		}
		else {
			System.out.println("Problem in Adding Customer");
		}
		out.println("Customer registered");
	}

}

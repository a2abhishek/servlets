package com.iris.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.daoimpl.CustomerDaoImpl;
import com.iris.daos.CustomerDao;
import com.iris.models.Customer;

/**
 * Servlet implementation class Updated
 */
@WebServlet("/Updated")
public class Updated extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		CustomerDao daoObj=new CustomerDaoImpl();
		String s1=request.getParameter("id");
		int a=Integer.parseInt(s1);
		String s2=request.getParameter("name").toLowerCase();
		String s3=request.getParameter("gender");
		String s4=request.getParameter("email");
		String s5=request.getParameter("password");
		String s6=request.getParameter("city");
		

		Customer custom=new Customer();
		
		custom.setCustomerName(s2);
		custom.setGender(s3);
		custom.setEmailAddress(s4);
		custom.setPassword(s5);
		custom.setCity(s6);
		custom.setCustomerId(a);
		boolean R = false;
		try {
			R = daoObj.registerUpdatedCustomer(custom);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(R==true){
			out.println("Customer updated");
			RequestDispatcher rd = request.getRequestDispatcher("ViewAll");
			rd.include(request, response);
			
			
		}
		else {
			System.out.println("Problem in Updating Customer");
		}
	}
}
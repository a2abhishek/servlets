package CustomerDaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import CustomerDaos.CustomerDaos;
import model.Customer;
import utility.ConnectionProvider;

public class CustomerDaoImpl implements CustomerDaos{
	Connection conn = ConnectionProvider.getConn();
	@Override
	public boolean register(Customer cust) throws Exception {			
		PreparedStatement ps = conn.prepareStatement("insert into customer1 values(id.nextval,?,?,?,?,?,'customer')");
		ps.setString(1,cust.getName());
		ps.setString(2,cust.getGender());
		ps.setString(3,cust.getEmail());
		ps.setString(4,cust.getPassword());
		ps.setString(5,cust.getCity());
		int i=ps.executeUpdate();
		if(i!=0){
			return true;
		}
		return false;
	}
	@Override
	public Customer validate(String name, String password) throws Exception {
		PreparedStatement ps = conn.prepareStatement("select * from customer1 where name=? and password=?");
		ps.setString(1,name);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
			Customer c= new Customer();
			c.setId(rs.getInt(1));
			c.setName(rs.getString(2));
			c.setGender(rs.getString(3));
			c.setEmail(rs.getString(4));
			c.setPassword(rs.getString(5));
			c.setCity(rs.getString(6));
			c.setRole(rs.getString(7));
			
			return c ;
		}
		return null;
	}

}

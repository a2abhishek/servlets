package CustomerDaos;

import model.Customer;

public interface CustomerDaos {
	public boolean register(Customer cust) throws Exception;

	public Customer validate(String name, String password) throws Exception;
}

package Controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import CustomerDaoImpl.CustomerDaoImpl;
import CustomerDaos.CustomerDaos;
import model.Customer;


/**
 * Servlet implementation class Insert
 */
@WebServlet("/Insert")
public class Insert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Insert() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		CustomerDaos daoObj=new CustomerDaoImpl();
		
	
		String s2=request.getParameter("custName").toLowerCase();
		String s3=request.getParameter("gender");
		String s4=request.getParameter("email");
		String s5=request.getParameter("password");
		String s6=request.getParameter("city");
		

		Customer custom=new Customer();
		
		custom.setName(s2);
		custom.setGender(s3);
		custom.setEmail(s4);
		custom.setPassword(s5);
		custom.setCity(s6);

		boolean r = false;
		try {
			r = daoObj.register(custom);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(r==true){
			out.println("Customer Registered");
		}
		else {
			System.out.println("Problem in Adding Customer");
		}
		out.println("Customer registered");
	}

}

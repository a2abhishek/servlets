package Controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import CustomerDaos.CustomerDaos;

import CustomerDaoImpl.CustomerDaoImpl;
import model.Customer;

/**
 * Servlet implementation class Updated
 */
@WebServlet("/Updated")
public class Updated extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Updated() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		CustomerDaos daoObj=new CustomerDaoImpl();
		String s1=request.getParameter("id");
		int a=Integer.parseInt(s1);
		String s2=request.getParameter("name").toLowerCase();
		String s3=request.getParameter("gender");
		String s4=request.getParameter("email");
		String s5=request.getParameter("password");
		String s6=request.getParameter("city");
		

		Customer custom=new Customer();
		
		custom.setName(s2);
		custom.setGender(s3);
		custom.setEmail(s4);
		custom.setPassword(s5);
		custom.setCity(s6);
		custom.setId(a);
		boolean R = false;
		try {
			R = daoObj.registerUpdatedCustomer(custom);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(R==true){
			out.println("Customer updated");
			RequestDispatcher rd = request.getRequestDispatcher("ViewAll");
			rd.include(request, response);
			
			
		}
		else {
			System.out.println("Problem in Updating Customer");
		}
	}

}

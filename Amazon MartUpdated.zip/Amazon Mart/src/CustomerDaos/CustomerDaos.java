package CustomerDaos;

import java.util.List;

import model.Customer;

public interface CustomerDaos {
	public boolean register(Customer cust) throws Exception;

	public Customer validate(String name, String password) throws Exception;
	
	public List<Customer> viewAllCustomers() throws Exception;
	
	public boolean delete(int id) throws Exception;
	
	public Customer updateCustomer(int id) throws Exception;
	
	public boolean registerUpdatedCustomer(Customer cust) throws Exception;
}
